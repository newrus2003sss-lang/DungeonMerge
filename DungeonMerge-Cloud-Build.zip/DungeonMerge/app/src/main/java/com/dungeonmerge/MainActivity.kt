package com.dungeonmerge

import android.app.Activity
import android.os.Bundle
import android.view.MotionEvent
import android.view.View
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Color
import android.graphics.RectF
import android.graphics.Typeface
import kotlin.math.max
import kotlin.math.min
import kotlin.random.Random

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(20, 24, 39)
        window.navigationBarColor = Color.rgb(20, 24, 39)
        setContentView(GameView())
    }
}

private data class Enemy(var x: Float, var y: Float, var hp: Int = 3, var speed: Float = 1.0f)
private data class Tower(var level: Int, var cooldown: Float = 0f)

class GameView : View {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var w = 1f
    private var h = 1f
    private var gold = 10
    private var ore = 0
    private var wave = 1
    private var baseHp = 10
    private var tick = 0
    private var spawnTimer = 0f
    private var gameOver = false
    private val enemies = mutableListOf<Enemy>()
    private val towers = Array(9) { Tower(0) }
    private val mine = Array(20) { Random.nextInt(0, 4) }
    private val mineDone = BooleanArray(20)
    private var lastTime = System.nanoTime()

    constructor() : super(null) {
        isFocusable = true
    }

    private fun color(c: Int) { p.color = c; p.style = Paint.Style.FILL }
    private fun rect(c: Canvas, x: Float, y: Float, ww: Float, hh: Float, col: Int, r: Float = 8f) {
        color(col); c.drawRoundRect(x, y, x + ww, y + hh, r, r, p)
    }
    private fun text(c: Canvas, s: String, x: Float, y: Float, size: Float, col: Int = Color.WHITE, bold: Boolean = false) {
        color(col); p.textSize = size; p.typeface = if (bold) Typeface.create("sans-serif", Typeface.BOLD) else Typeface.create("sans-serif", Typeface.NORMAL)
        c.drawText(s, x, y, p)
    }
    private fun circle(c: Canvas, x: Float, y: Float, r: Float, col: Int) {
        color(col); c.drawCircle(x, y, r, p)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        w = width.toFloat(); h = height.toFloat()
        canvas.drawColor(Color.rgb(18, 23, 39))
        val scale = w / 360f
        val topH = h * 0.42f
        // Header
        text(canvas, "DUNGEON MERGE", 18f * scale, 34f * scale, 22f * scale, Color.rgb(255, 220, 125), true)
        text(canvas, "Волна $wave", 18f * scale, 58f * scale, 14f * scale, Color.WHITE, true)
        text(canvas, "⛃ $gold     ◆ $ore     ♥ $baseHp", 175f * scale, 58f * scale, 14f * scale, Color.rgb(170, 240, 190), true)

        // Mine area
        rect(canvas, 10f * scale, 75f * scale, w - 20f * scale, topH - 82f * scale, Color.rgb(44, 42, 62), 14f * scale)
        text(canvas, "ШАХТА · нажми на блок", 20f * scale, 99f * scale, 13f * scale, Color.rgb(230, 214, 190), true)
        val cols = 5
        val gap = 5f * scale
        val tile = (w - 40f * scale - gap * 4) / cols
        for (i in mine.indices) {
            val row = i / cols; val col = i % cols
            val x = 20f * scale + col * (tile + gap)
            val y = 111f * scale + row * (tile * 0.63f + gap)
            val base = when (mine[i]) {
                0 -> Color.rgb(78, 76, 94)
                1 -> Color.rgb(99, 78, 61)
                2 -> Color.rgb(48, 115, 126)
                else -> Color.rgb(125, 84, 158)
            }
            rect(canvas, x, y, tile, tile * 0.58f, if (mineDone[i]) Color.rgb(29, 33, 45) else base, 5f * scale)
            if (!mineDone[i]) {
                val gem = when (mine[i]) {
                    0 -> Color.rgb(150, 150, 170)
                    1 -> Color.rgb(225, 166, 85)
                    2 -> Color.rgb(89, 230, 220)
                    else -> Color.rgb(218, 131, 255)
                }
                circle(canvas, x + tile / 2, y + tile * 0.29f, tile * 0.13f, gem)
            } else {
                text(canvas, "·", x + tile * .42f, y + tile * .4f, 18f * scale, Color.GRAY)
            }
        }

        // Defense arena
        val arenaY = topH + 10f * scale
        rect(canvas, 10f * scale, arenaY, w - 20f * scale, h - arenaY - 104f * scale, Color.rgb(32, 55, 59), 14f * scale)
        text(canvas, "ЗАЩИТА БАЗЫ · объедини одинаковых", 20f * scale, arenaY + 24f * scale, 12f * scale, Color.rgb(195, 239, 218), true)
        val pathY = arenaY + 55f * scale
        rect(canvas, 20f * scale, pathY, w - 40f * scale, 24f * scale, Color.rgb(74, 81, 85), 12f * scale)
        // enemies on the path
        enemies.forEach { e ->
            circle(canvas, e.x * scale, e.y * scale, 10f * scale, Color.rgb(240, 98, 104))
            circle(canvas, (e.x - 3f) * scale, (e.y - 2f) * scale, 2f * scale, Color.WHITE)
            rect(canvas, (e.x - 10f) * scale, (e.y - 15f) * scale, 20f * scale * (e.hp / 3f).coerceIn(.15f, 1f), 3f * scale, Color.rgb(255, 211, 115), 2f)
        }
        // 3x3 tower board
        val boardTop = arenaY + 95f * scale
        val cell = min((w - 50f * scale) / 3f, (h - boardTop - 90f * scale) / 3f)
        for (i in towers.indices) {
            val row = i / 3; val col = i % 3
            val x = 20f * scale + col * (cell + 5f * scale)
            val y = boardTop + row * (cell * .68f + 5f * scale)
            rect(canvas, x, y, cell, cell * .62f, Color.rgb(51, 69, 83), 8f * scale)
            val t = towers[i]
            if (t.level > 0) {
                val cc = when (t.level % 4) {
                    1 -> Color.rgb(94, 206, 255)
                    2 -> Color.rgb(140, 255, 157)
                    3 -> Color.rgb(255, 193, 91)
                    else -> Color.rgb(219, 131, 255)
                }
                circle(canvas, x + cell / 2, y + cell * .3f, cell * .2f, cc)
                text(canvas, "Lv.${t.level}", x + cell * .22f, y + cell * .57f, 11f * scale, Color.WHITE, true)
            } else {
                text(canvas, "+", x + cell * .39f, y + cell * .43f, 24f * scale, Color.rgb(180, 197, 207), true)
            }
        }

        // Buttons
        val btnY = h - 82f * scale
        rect(canvas, 12f * scale, btnY, w * .48f, 54f * scale, Color.rgb(180, 112, 62), 13f * scale)
        text(canvas, "ПРИЗВАТЬ · 5", 25f * scale, btnY + 33f * scale, 15f * scale, Color.WHITE, true)
        rect(canvas, w * .54f, btnY, w * .44f - 12f * scale, 54f * scale, Color.rgb(59, 123, 113), 13f * scale)
        text(canvas, "НОВАЯ ВОЛНА", w * .58f, btnY + 33f * scale, 13f * scale, Color.WHITE, true)

        if (!gameOver) updateGame(scale, arenaY, pathY)
        else {
            rect(canvas, 30f * scale, h * .42f, w - 60f * scale, 95f * scale, Color.rgb(75, 35, 47), 16f * scale)
            text(canvas, "БАЗА ПАЛА", 90f * scale, h * .42f + 38f * scale, 24f * scale, Color.WHITE, true)
            text(canvas, "Нажми, чтобы начать заново", 52f * scale, h * .42f + 68f * scale, 14f * scale)
        }
        postInvalidateDelayed(80)
    }

    private fun updateGame(scale: Float, arenaY: Float, pathY: Float) {
        val now = System.nanoTime()
        val dt = ((now - lastTime) / 1_000_000_000f).coerceIn(0f, .12f)
        lastTime = now
        tick++
        spawnTimer += dt
        if (spawnTimer > max(1.2f, 3.8f - wave * .12f)) {
            spawnTimer = 0f
            enemies.add(Enemy(w - 25f, pathY / scale + 12f, 2 + wave / 3, 14f + wave * 1.2f))
        }
        val iterator = enemies.iterator()
        while (iterator.hasNext()) {
            val e = iterator.next()
            e.x -= e.speed * dt
            if (e.x < 22f) {
                baseHp--
                iterator.remove()
                if (baseHp <= 0) gameOver = true
            }
        }
        // Towers auto-attack nearest enemy in range
        towers.forEach { t ->
            if (t.level <= 0) return@forEach
            t.cooldown -= dt
            if (t.cooldown <= 0f && enemies.isNotEmpty()) {
                val target = enemies.minByOrNull { it.x } ?: return@forEach
                target.hp -= 1 + t.level / 3
                t.cooldown = max(.25f, 1.2f - t.level * .06f)
                if (target.hp <= 0) {
                    enemies.remove(target)
                    gold += 2 + wave / 2
                    ore += 1
                }
            }
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (event.action != MotionEvent.ACTION_UP) return true
        val sx = width / 360f
        val x = event.x / sx
        val y = event.y / sx
        val topH = height * .42f / sx
        if (gameOver) {
            gameOver = false; baseHp = 10; gold = 10; ore = 0; wave = 1
            enemies.clear(); towers.forEach { it.level = 0; it.cooldown = 0f }
            mineDone.indices.forEach { mineDone[it] = false }
            invalidate(); return true
        }
        // Mine block grid
        val tile = (width / sx - 40f - 20f) / 5f
        val gap = 5f
        for (i in mine.indices) {
            val row = i / 5; val col = i % 5
            val tx = 20f + col * (tile + gap)
            val ty = 111f + row * (tile * .63f + gap)
            if (x in tx..(tx + tile) && y in ty..(ty + tile * .58f) && !mineDone[i]) {
                mineDone[i] = true
                when (mine[i]) {
                    0 -> gold += 2
                    1 -> { gold += 4; ore += 1 }
                    2 -> { gold += 2; ore += 2 }
                    else -> { gold += 1; ore += 3 }
                }
                invalidate(); return true
            }
        }
        val arenaY = topH + 10f
        val boardTop = arenaY + 95f
        val cell = min((360f - 50f) / 3f, (height / sx - boardTop - 90f) / 3f)
        for (i in towers.indices) {
            val row = i / 3; val col = i % 3
            val tx = 20f + col * (cell + 5f)
            val ty = boardTop + row * (cell * .68f + 5f)
            if (x in tx..(tx + cell) && y in ty..(ty + cell * .62f)) {
                val t = towers[i]
                if (t.level == 0 && gold >= 5) {
                    gold -= 5; t.level = Random.nextInt(1, 3)
                } else if (t.level > 0) {
                    val other = towers.indices.firstOrNull { it != i && towers[it].level == t.level }
                    if (other != null) {
                        towers[other].level = 0
                        t.level = min(6, t.level + 1)
                    }
                }
                invalidate(); return true
            }
        }
        val btnY = height / sx - 82f
        if (y in btnY..(btnY + 54f)) {
            if (x < 180f && gold >= 5) {
                val empty = towers.indices.firstOrNull { towers[it].level == 0 }
                if (empty != null) {
                    gold -= 5
                    towers[empty].level = Random.nextInt(1, 3)
                }
            } else if (x >= 180f) {
                wave++
                spawnTimer = 0f
                enemies.add(Enemy(330f, (arenaY + 67f), 2 + wave / 3, 14f + wave))
            }
        }
        invalidate()
        return true
    }
}
