# Dungeon Merge — Android prototype

A small original Android game prototype combining mining, tower defense, and merging units.

## Gameplay
- Tap cave blocks to collect gold and ore.
- Summon towers for 5 gold.
- Tap a tower and merge it with another tower of the same level.
- Towers automatically attack incoming enemies.
- Tap “Новая волна” to increase difficulty.
- If the base HP reaches zero, tap the screen to restart.

## Build an APK
1. Install Android Studio and JDK 17.
2. Open this folder in Android Studio.
3. Install Android SDK Platform 35 if prompted and sync Gradle.
4. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
5. The debug APK should appear at `app/build/outputs/apk/debug/app-debug.apk`.

This archive contains source code, not a prebuilt APK. The project has not been compiled or tested on a physical device in this environment.
